<header class="bg-theme-overlay">
  <!-- <div class="bg-overlay-one"></div> -->
  <!-- NAVBAR -->
  <nav class="navbar navbar-hover navbar-expand-lg navbar-soft navbar-transparent">
    <div class="container">
      <a class='navbar-brand' href='/'>
        <img src="/images/logo-blue.png" alt="">
        <img src="/images/logo-blue-stiky.png" alt="">
      </a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#main_nav99">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="main_nav99">
        <ul class="navbar-nav mx-auto ">
          <li class="nav-item dropdown">
            <a class="nav-link" href="#" data-toggle="dropdown"> Mới nhất </a>

          </li>
          <li class="nav-item dropdown">
            <a class="nav-link" href="#" data-toggle="dropdown"> Quan tâm nhất </a>

          </li>

          <li class="nav-item dropdown">
            <a class="nav-link" href="#" data-toggle="dropdown"> Giá tốt nhất </a>

          </li>


        </ul>


        <!-- Search bar.// -->
        <ul class="navbar-nav ">
          @if(Auth::check())
            <li>
              <a href="javascript:void(0)" class="btn btn-primary text-capitalize">
                <i class="fa fa-user mr-1"></i>Xin chào, {{Auth::user()->name}} </a>

            </li>
            <li style="padding-left: 10px">
              <a href="{{ route('logout') }}"
                 onclick="event.preventDefault(); document.getElementById('logout-form').submit();" class="btn btn-danger text-capitalize">
                <i class="fa fa-sign-out mr-1"></i>Đăng xuất </a>
              <form method="POST" id="logout-form" action="{{ route('logout') }}">
                @csrf
              </form>
            </li>
          @else
            <li>
              <a href="/login" class="btn btn-primary text-capitalize">
                <i class="fa fa-user mr-1"></i> Đăng nhập </a>
            </li>
          @endif

        </ul>
        <!-- Search content bar.// -->
        <div class="top-search navigation-shadow">
          <div class="container">
            <div class="input-group ">
              <form action="#">

                <div class="row no-gutters mt-3">
                  <div class="col">
                    <input class="form-control border-secondary border-right-0 rounded-0"
                           type="search" value="" placeholder="Search " id="example-search-input4">
                  </div>
                  <div class="col-auto">
                    <a class="btn btn-outline-secondary border-left-0 rounded-0 rounded-right"
                       href="https://wallsproperty.netlify.app/search-result.html">
                      <i class="fa fa-search"></i>
                    </a>
                  </div>
                </div>

              </form>
            </div>
          </div>
        </div>
        <!-- Search content bar.// -->
      </div> <!-- navbar-collapse.// -->
    </div>
  </nav>
  <!-- END NAVBAR -->
  <!-- BREADCRUMB -->
  <!-- BREADCRUMB -->
  <section class="section__breadcrumb ">
    <div class="container">
      <div class="row d-flex justify-content-center">
        <div class="col-md-8 text-center">
          <h2 class="text-capitalize text-white ">Nhà phố Thuận An</h2>
          <p class="text-white">Địa chỉ: 34 Ấp 456, phường 5, Thuận An, Bình Dương</p>

        </div>
        <div class="col-md-4 text-center">
                        <span style="border-radius: 15px; font-size: 15pt" class="badge badge-primary">Giá hiện tại:
                            1,500,000,000</span>
          <main>
            <div id="countdown">
              <div class="countdown__container">
                <div class="countdown__el">
                  <div class="countdown__time flip" id="days">
                    <span class="count curr top"></span>
                    <span class="count next top">20</span>
                    <span class="count curr bottom">20</span>
                    <span class="count next bottom"></span>
                  </div>
                  <span class="countdown__label">Ngày</span>
                </div>
                <div class="countdown__el">
                  <div class="countdown__time flip" id="hours">
                    <span class="count curr top"></span>
                    <span class="count next top">10</span>
                    <span class="count curr bottom">10</span>
                    <span class="count next bottom"></span>
                  </div>
                  <span class="countdown__label">Giờ</span>
                </div>
                <div class="countdown__el">
                  <div class="countdown__time flip" id="mins">
                    <span class="count curr top"></span>
                    <span class="count next top">07</span>
                    <span class="count curr bottom">07</span>
                    <span class="count next bottom"></span>
                  </div>
                  <span class="countdown__label">Phút</span>
                </div>
                <div class="countdown__el">
                  <div class="countdown__time flip" id="seconds">
                    <span class="count curr top"></span>
                    <span class="count next top">10</span>
                    <span class="count curr bottom">10</span>
                    <span class="count next bottom"></span>
                  </div>
                  <span class="countdown__label">Giây</span>
                </div>
              </div>
            </div>
          </main>
        </div>
      </div>
    </div>
  </section>
  <!-- END BREADCRUMB -->
  <!-- END BREADCRUMB -->
</header>
<div class="clearfix"></div>
